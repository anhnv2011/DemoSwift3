//
//  Rectangle.hpp
//  DemoSwift3
//
//  Created by Techmaster on 9/16/16.
//  Copyright © 2016 TechMaster. All rights reserved.
//

#ifndef Rectangle_hpp
#define Rectangle_hpp

#include <stdio.h>
class Rectangle {
    int width, height;
public:
    Rectangle(int,int);
    int area (void);
};
#endif /* Rectangle_hpp */
